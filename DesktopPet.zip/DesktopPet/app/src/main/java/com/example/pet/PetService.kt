package com.example.pet

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.speech.*
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import kotlin.math.abs

/** 悬浮在所有应用之上的桌宠 */
class PetService : Service() {
    companion object { var instance: PetService? = null }

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var prefs: Prefs
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var root: LinearLayout
    private lateinit var bubble: TextView
    private lateinit var panel: LinearLayout
    private lateinit var input: EditText
    private lateinit var wardrobe: HorizontalScrollView
    private lateinit var hat: TextView
    private lateinit var body: TextView
    private var sleeping = false
    private var feedMode = false
    private var rec: SpeechRecognizer? = null
    private var typer: Runnable? = null
    private val hideBubble = Runnable { if (panel.visibility != View.VISIBLE) bubble.visibility = View.GONE }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        prefs = Prefs(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startAsForeground()
        buildUi()
        refresh()
        listen()
        say("我来啦～ 有事就叫我「${prefs.name}」")
    }

    override fun onDestroy() {
        instance = null
        rec?.destroy()
        if (::root.isInitialized) wm.removeView(root)
        super.onDestroy()
    }

    private fun startAsForeground() {
        val ch = "pet"
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(NotificationChannel(ch, "桌宠", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, ch).setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("${prefs.name} 正在陪着你").build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
    }

    // ───────────── 界面 ─────────────
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun round(color: String, r: Int = 16) = GradientDrawable().apply {
        setColor(Color.parseColor(color)); cornerRadius = dp(r).toFloat()
        setStroke(dp(1), Color.parseColor("#22000000"))
    }
    private fun chip(t: String, size: Float = 14f, onClick: () -> Unit) = TextView(this).apply {
        text = t; textSize = size; setPadding(dp(10), dp(6), dp(10), dp(6))
        background = round("#FFFFFF", 14); setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
    }

    private fun buildUi() {
        bubble = TextView(this).apply {
            textSize = 14f; setTextColor(Color.parseColor("#333333")); maxWidth = dp(230)
            setPadding(dp(12), dp(8), dp(12), dp(8)); background = round("#FFFFFF"); visibility = View.GONE
        }
        input = EditText(this).apply {
            textSize = 14f; maxLines = 3
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        val inputRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(input); addView(chip("发送") { sendInput() })
        }
        val tools = LinearLayout(this).apply {
            addView(chip("🍖 喂食") { toggleFeed() })
            addView(chip("😴 睡觉") { toggleSleep() })
            addView(chip("👗 换装") { wardrobe.visibility = if (wardrobe.visibility == View.VISIBLE) View.GONE else View.VISIBLE })
            addView(chip("✕") { openPanel(false) })
        }
        val costumeRow = LinearLayout(this)
        Prefs.COSTUMES.forEach { c ->
            costumeRow.addView(chip(if (c.isEmpty()) "无" else c, 20f) { prefs.costume = c; refresh() })
        }
        wardrobe = HorizontalScrollView(this).apply { addView(costumeRow); visibility = View.GONE }
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            setPadding(dp(8), dp(8), dp(8), dp(8)); background = round("#F2F2F2")
            minimumWidth = dp(260)
            addView(inputRow); addView(tools); addView(wardrobe)
        }
        hat = TextView(this).apply { textSize = 24f; gravity = Gravity.CENTER; translationY = dp(8).toFloat() }
        body = TextView(this).apply { textSize = 56f; gravity = Gravity.CENTER }
        val pet = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            addView(hat); addView(body)
            setOnTouchListener(dragListener())
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            addView(bubble); addView(panel); addView(pet)
        }
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(20); y = dp(300) }
        wm.addView(root, lp)
        ObjectAnimator.ofFloat(body, "translationY", 0f, -dp(6).toFloat()).apply {
            duration = 700; repeatMode = ValueAnimator.REVERSE; repeatCount = ValueAnimator.INFINITE; start()
        }
    }

    private fun dragListener() = object : View.OnTouchListener {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    if (moved) { lp.x = ox + dx.toInt(); lp.y = oy + dy.toInt(); wm.updateViewLayout(root, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) onPetTap()
            }
            return true
        }
    }

    /** 名字/外形/服装/性格改了以后刷新 */
    fun refresh() {
        body.text = prefs.body
        hat.text = prefs.costume
        body.alpha = if (sleeping) 0.5f else 1f
        input.hint = if (feedMode) "想喂${prefs.name}吃什么？" else "和${prefs.name}说点什么…"
    }

    private fun openPanel(open: Boolean) {
        panel.visibility = if (open) View.VISIBLE else View.GONE
        wardrobe.visibility = View.GONE
        lp.flags = if (open) lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        else lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        wm.updateViewLayout(root, lp)
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        if (open) { input.requestFocus(); imm.showSoftInput(input, 0) }
        else imm.hideSoftInputFromWindow(input.windowToken, 0)
    }

    // ───────────── 说话 / 动作 ─────────────
    private fun say(t: String) {
        typer?.let { ui.removeCallbacks(it) }
        ui.removeCallbacks(hideBubble)
        bubble.visibility = View.VISIBLE; bubble.text = ""
        var i = 0
        val r = object : Runnable {
            override fun run() {
                i++; bubble.text = t.take(i)
                if (i < t.length) ui.postDelayed(this, 45) else ui.postDelayed(hideBubble, 9000)
            }
        }
        typer = r; ui.post(r)
    }

    private fun talk(msg: String) {
        if (prefs.apiKey.isBlank()) { say("先去设置里填好 API Key，我才能开口说话～"); return }
        say("…")
        Brain.chat(prefs, msg, if (sleeping) "睡觉中" else "清醒") { reply, action ->
            ui.post {
                say(reply)
                action?.let { a -> Actions.run(this, a)?.let { err -> ui.postDelayed({ say(err) }, 2500) } }
            }
        }
    }

    private fun onPetTap() {
        if (sleeping) { setSleeping(false); talk("[主人轻轻拍醒了你]"); return }
        openPanel(panel.visibility != View.VISIBLE)
    }

    private fun sendInput() {
        val t = input.text.toString().trim(); if (t.isEmpty()) return
        input.setText("")
        val wasSleeping = sleeping
        setSleeping(false)
        if (feedMode) {
            feedMode = false; refresh(); wiggle()
            talk("[主人喂你吃了：$t]")
        } else talk(if (wasSleeping) "[你被吵醒了] $t" else t)
    }

    private fun toggleFeed() { feedMode = !feedMode; refresh(); if (feedMode) input.requestFocus() }

    private fun toggleSleep() {
        if (sleeping) { setSleeping(false); talk("[主人叫醒了你]") }
        else { setSleeping(true); openPanel(false); talk("[主人让你去睡觉了，说句晚安]") }
    }

    private fun setSleeping(s: Boolean) {
        sleeping = s; refresh()
        hat.text = (if (s) "💤 " else "") + prefs.costume
    }

    private fun wiggle() {
        ObjectAnimator.ofFloat(body, "rotation", 0f, -14f, 14f, -14f, 14f, 0f).setDuration(900).start()
    }

    // ───────────── 语音唤醒：喊它的名字 ─────────────
    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        rec?.destroy()
        rec = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle?) {
                    b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { heard(it) }
                    again()
                }
                override fun onError(error: Int) = again()
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(b: Bundle?) {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "zh-CN"))
        }
    }

    private fun again() { ui.postDelayed({ if (instance != null) listen() }, 700) }

    private fun heard(text: String) {
        val n = prefs.name
        if (!text.contains(n, ignoreCase = true)) return
        val rest = text.replace(n, "", ignoreCase = true)
            .replace(Regex("^\\s*(hey|hi|hello)\\s*", RegexOption.IGNORE_CASE), "")
            .trimStart(' ', '，', ',', '。', '嘿', '喂', '哎').trim()
        val wasSleeping = sleeping
        setSleeping(false)
        val prefix = if (wasSleeping) "[你被主人喊醒了] " else ""
        talk(prefix + rest.ifBlank { "[主人在叫你的名字]" })
    }
}
