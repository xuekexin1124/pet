package com.example.pet

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
    private lateinit var prefs: Prefs
    private lateinit var name: EditText
    private lateinit var persona: EditText
    private lateinit var key: EditText
    private lateinit var model: EditText
    private lateinit var base: EditText

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = Prefs(this)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }

        fun label(t: String) = col.addView(TextView(this).apply { text = t; textSize = 13f; setPadding(0, pad / 2, 0, 0) })
        fun btn(t: String, f: () -> Unit) = col.addView(Button(this).apply { text = t; setOnClickListener { f() } })

        label("宠物名字（语音喊这个名字唤醒它）")
        name = EditText(this).apply { setText(prefs.name) }; col.addView(name)
        label("性格设定（想怎么写都行）")
        persona = EditText(this).apply { setText(prefs.persona); minLines = 3; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE }
        col.addView(persona)
        label("API Key（智谱 glm-4-flash 免费，见说明）")
        key = EditText(this).apply { setText(prefs.apiKey); inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        col.addView(key)
        label("接口地址（换模型服务商时才改）")
        base = EditText(this).apply { setText(prefs.baseUrl) }; col.addView(base)
        label("模型")
        model = EditText(this).apply { setText(prefs.model) }; col.addView(model)

        btn("选择外形") {
            AlertDialog.Builder(this).setItems(Prefs.BODIES.toTypedArray()) { _, i ->
                prefs.body = Prefs.BODIES[i]; PetService.instance?.refresh()
            }.show()
        }
        btn("1. 授权悬浮窗") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("2. 授权麦克风 / 通讯录 / 通知") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS,
                Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        btn("3. 召唤桌宠 🐾") {
            save()
            if (!Settings.canDrawOverlays(this)) toast("请先授权悬浮窗")
            else { startForegroundService(Intent(this, PetService::class.java)); PetService.instance?.refresh() }
        }
        btn("收起桌宠") { stopService(Intent(this, PetService::class.java)) }

        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun save() {
        prefs.name = name.text.toString().ifBlank { "团子" }
        prefs.persona = persona.text.toString()
        prefs.apiKey = key.text.toString().trim()
        prefs.model = model.text.toString().trim().ifBlank { "glm-4-flash" }
        prefs.baseUrl = base.text.toString().trim()
        PetService.instance?.refresh()
    }

    override fun onPause() { save(); super.onPause() }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
