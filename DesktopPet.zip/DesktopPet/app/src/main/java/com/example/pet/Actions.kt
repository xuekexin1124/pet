package com.example.pet

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import org.json.JSONObject

/** 负责"动手"：闹钟、计时、电话、短信 */
object Actions {
    /** 成功返回 null，失败返回要让宠物说的话 */
    fun run(c: Context, a: JSONObject): String? = try {
        when (a.optString("type")) {
            "alarm" -> go(c, Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, a.optInt("hour"))
                .putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute"))
                .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label"))
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            "timer" -> go(c, Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, a.optInt("seconds", 60))
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            "call" -> number(c, a.optString("to"))?.let {
                go(c, Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(it))))
            } ?: "通讯录里没找到这个人…"
            "sms" -> number(c, a.optString("to"))?.let {
                go(c, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(it)))
                    .putExtra("sms_body", a.optString("text")))
            } ?: "通讯录里没找到这个人…"
            else -> null
        }
    } catch (e: Exception) { "这个我没办成：${e.message}" }

    private fun go(c: Context, i: Intent): String? {
        c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return null
    }

    private fun number(c: Context, who: String): String? {
        if (who.matches(Regex("[+\\d\\s-]{3,}"))) return who
        c.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%$who%"), null
        )?.use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }
}
