package com.example.pet

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 负责"思考"：把话发给大模型，拿回 台词 + 可选动作 */
object Brain {
    private val history = mutableListOf<Pair<String, String>>() // role to text

    fun chat(p: Prefs, msg: String, state: String, cb: (String, JSONObject?) -> Unit) {
        Thread {
            synchronized(history) { history.add("user" to msg) }
            val result = try { call(p, state) } catch (e: Exception) {
                synchronized(history) { history.removeAt(history.lastIndex) }
                "（网络开小差了，等我一下再试试）" to null
            }
            synchronized(history) { history.add("assistant" to result.first) }
            cb(result.first, result.second)
        }.start()
    }

    private fun call(p: Prefs, state: String): Pair<String, JSONObject?> {
        val now = SimpleDateFormat("yyyy-MM-dd HH:mm EEEE", Locale.CHINA).format(Date())
        val system = """
你是主人手机桌面上的一只电子宠物，名字叫「${p.name}」，外形是 ${p.body}。
性格：${p.persona}
当前时间：$now；你现在的状态：$state。
规则：
- 像真正的小伙伴那样聊天，口语化，1~2 句话，别说教，别自称AI。
- 主人喂你任何东西（再奇怪也行）你都开心地吃下去，并按你的性格点评味道。
- 睡觉中被吵醒要带点迷糊/起床气。
- 主人要定闹钟、计时、打电话、发短信时，在 action 里给出指令。
只输出一个 JSON，不要其它文字：
{"reply":"你要说的话","action":null}
action 可选格式：
{"type":"alarm","hour":7,"minute":30,"label":"起床"}
{"type":"timer","seconds":300}
{"type":"call","to":"联系人名或号码"}
{"type":"sms","to":"联系人名或号码","text":"短信内容"}
""".trimIndent()

        val msgs = JSONArray()
        synchronized(history) {
            val recent = history.takeLast(24).dropWhile { it.first != "user" }
            recent.forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
        }
        val anthropic = p.baseUrl.contains("anthropic.com")
        val conn = URL(p.baseUrl).openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 15000; conn.readTimeout = 40000
        conn.setRequestProperty("content-type", "application/json")
        val body = JSONObject().put("model", p.model).put("max_tokens", 400)
        if (anthropic) {
            conn.setRequestProperty("x-api-key", p.apiKey)
            conn.setRequestProperty("anthropic-version", "2023-06-01")
            body.put("system", system).put("messages", msgs)
        } else {
            conn.setRequestProperty("Authorization", "Bearer " + p.apiKey)
            val all = JSONArray().put(JSONObject().put("role", "system").put("content", system))
            for (i in 0 until msgs.length()) all.put(msgs.get(i))
            body.put("messages", all)
        }
        conn.doOutput = true
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        if (conn.responseCode !in 200..299) throw RuntimeException("HTTP ${conn.responseCode}")
        val resp = JSONObject(conn.inputStream.bufferedReader().readText())
        val text = if (anthropic) resp.getJSONArray("content").getJSONObject(0).getString("text")
        else resp.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")

        val s = text.indexOf('{'); val e = text.lastIndexOf('}')
        return try {
            val j = JSONObject(text.substring(s, e + 1))
            j.optString("reply", text) to j.optJSONObject("action")
        } catch (x: Exception) { text.trim() to null }
    }
}
