package com.example.pet

import android.content.Context

class Prefs(c: Context) {
    private val sp = c.getSharedPreferences("pet", Context.MODE_PRIVATE)
    private fun s(k: String, d: String) = sp.getString(k, d) ?: d

    var name: String get() = s("name", "团子"); set(v) = sp.edit().putString("name", v).apply()
    var persona: String
        get() = s("persona", "温柔又有点小傲娇的小伙伴，爱撒娇，偶尔吐槽主人，说话自然像朋友，不啰嗦。")
        set(v) = sp.edit().putString("persona", v).apply()
    var apiKey: String get() = s("key", ""); set(v) = sp.edit().putString("key", v).apply()
    var model: String get() = s("model2", "glm-4-flash"); set(v) = sp.edit().putString("model2", v).apply()
    var baseUrl: String
        get() = s("base2", "https://open.bigmodel.cn/api/paas/v4/chat/completions")
        set(v) = sp.edit().putString("base2", v).apply()
    var body: String get() = s("body", "🐱"); set(v) = sp.edit().putString("body", v).apply()
    var costume: String get() = s("costume", ""); set(v) = sp.edit().putString("costume", v).apply()

    companion object {
        val BODIES = listOf("🐱", "🐶", "🐰", "🐼", "🦊", "🐸", "🐧", "🐹")
        val COSTUMES = listOf("", "🎩", "👑", "🎀", "🧢", "🎓", "😎", "🎅", "🌸", "⭐")
    }
}
